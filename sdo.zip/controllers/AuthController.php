<?php


namespace app\controllers;


use app\models\LoginForm;
use app\models\User;
use Codeception\Module\Yii2;
use yii\web\Controller;
use yii\web\Response;
use Yii;

class AuthController extends Controller
{
    public function actionLogin()
    {
        if (!Yii::$app->user->isGuest) {
            return $this->goHome();
        }

        $model = new LoginForm();
        if ($model->load(Yii::$app->request->post()) && $model->login()) {
            return $this->goBack();
        }

        $model->password = '';
        return $this->render('login', [
            'model' => $model,
        ]);
    }

    /**
     * Logout action.
     *
     * @return Response
     */
    public function actionLogout()
    {
        Yii::$app->user->logout();

        return $this->goHome();
    }

    public function actionTest()
    {
        $user = User::findeOne(1);
        Yii::$app->user->login($user);
        if(Yii::$app->user->isGuest){
            echo 'Пользователь гость';
        }else{
            echo 'Пользователь авторизован!';
        }
    }
}