<?php

namespace app\modules\simpleactiveform;

class Module extends \yii\base\Module
{
    public $controllerNamespace = 'app\modules\simpleactiveform\controllers';

    public function init()
    {
        parent::init();

        // custom initialization code goes here
    }
}
