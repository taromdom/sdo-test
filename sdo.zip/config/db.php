<?php

return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=localhost;dbname=brdzaz0xlqvzlaam0wq7',
    'username' => 'uzlcowbierxdzfq0',
    'password' => 'o24tWjsRs8z0pk2Nw2r4',
    'charset' => 'utf8',

    // Schema cache options (for production environment)
    //'enableSchemaCache' => true,
    //'schemaCacheDuration' => 60,
    //'schemaCache' => 'cache',
];
